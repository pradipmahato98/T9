import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import { Button } from './components/ui/button'
import { Tabs, TabsList, TabsTrigger } from './components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar'
import { Bell, Menu, X } from 'lucide-react'
import MarketDashboard from './components/MarketDashboard'
import UserProfile from './components/UserProfile'
import './App.css'

function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="container mx-auto px-4 py-3 flex justify-between items-center">
            <div className="flex items-center">
              <Link to="/" className="text-xl font-bold text-blue-600">FinMarkets</Link>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              <Tabs defaultValue="dashboard" className="w-fit">
                <TabsList>
                  <Link to="/">
                    <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
                  </Link>
                  <Link to="/markets">
                    <TabsTrigger value="markets">Markets</TabsTrigger>
                  </Link>
                  <Link to="/forex">
                    <TabsTrigger value="forex">Forex</TabsTrigger>
                  </Link>
                  <Link to="/crypto">
                    <TabsTrigger value="crypto">Crypto</TabsTrigger>
                  </Link>
                  <Link to="/commodities">
                    <TabsTrigger value="commodities">Commodities</TabsTrigger>
                  </Link>
                </TabsList>
              </Tabs>
            </nav>
            
            {/* User Menu */}
            <div className="hidden md:flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <Link to="/profile">
                <Avatar>
                  <AvatarImage src="https://i.pravatar.cc/300" alt="User" />
                  <AvatarFallback>AJ</AvatarFallback>
                </Avatar>
              </Link>
            </div>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
          
          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-white border-t">
              <div className="container mx-auto px-4 py-3 space-y-2">
                <Link to="/" className="block py-2 hover:bg-gray-50 rounded-md px-3" onClick={() => setIsMobileMenuOpen(false)}>
                  Dashboard
                </Link>
                <Link to="/markets" className="block py-2 hover:bg-gray-50 rounded-md px-3" onClick={() => setIsMobileMenuOpen(false)}>
                  Markets
                </Link>
                <Link to="/forex" className="block py-2 hover:bg-gray-50 rounded-md px-3" onClick={() => setIsMobileMenuOpen(false)}>
                  Forex
                </Link>
                <Link to="/crypto" className="block py-2 hover:bg-gray-50 rounded-md px-3" onClick={() => setIsMobileMenuOpen(false)}>
                  Crypto
                </Link>
                <Link to="/commodities" className="block py-2 hover:bg-gray-50 rounded-md px-3" onClick={() => setIsMobileMenuOpen(false)}>
                  Commodities
                </Link>
                <Link to="/profile" className="block py-2 hover:bg-gray-50 rounded-md px-3" onClick={() => setIsMobileMenuOpen(false)}>
                  Profile
                </Link>
              </div>
            </div>
          )}
        </header>
        
        {/* Main Content */}
        <main className="py-6">
          <Routes>
            <Route path="/" element={<MarketDashboard />} />
            <Route path="/profile" element={<UserProfile />} />
            <Route path="/markets" element={<div className="container mx-auto px-4"><h1 className="text-3xl font-bold mb-6">Markets</h1><p>Markets content will be displayed here.</p></div>} />
            <Route path="/forex" element={<div className="container mx-auto px-4"><h1 className="text-3xl font-bold mb-6">Forex</h1><p>Forex content will be displayed here.</p></div>} />
            <Route path="/crypto" element={<div className="container mx-auto px-4"><h1 className="text-3xl font-bold mb-6">Cryptocurrency</h1><p>Cryptocurrency content will be displayed here.</p></div>} />
            <Route path="/commodities" element={<div className="container mx-auto px-4"><h1 className="text-3xl font-bold mb-6">Commodities</h1><p>Commodities content will be displayed here.</p></div>} />
          </Routes>
        </main>
        
        {/* Footer */}
        <footer className="bg-white border-t mt-auto">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <p className="text-sm text-gray-600">&copy; 2025 FinMarkets. All rights reserved.</p>
              </div>
              <div className="flex space-x-4">
                <a href="#" className="text-sm text-gray-600 hover:text-blue-600">Terms of Service</a>
                <a href="#" className="text-sm text-gray-600 hover:text-blue-600">Privacy Policy</a>
                <a href="#" className="text-sm text-gray-600 hover:text-blue-600">Contact Us</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  )
}

export default App

