import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';

const MarketDashboard = () => {
  const [activeRegion, setActiveRegion] = useState('usa');
  const [marketData, setMarketData] = useState([]);
  const [topGainers, setTopGainers] = useState([]);
  const [topLosers, setTopLosers] = useState([]);
  const [marketNews, setMarketNews] = useState([]);
  const [loading, setLoading] = useState({
    marketData: true,
    gainers: true,
    losers: true,
    news: true
  });

  // Backend API URL - will be replaced with environment variable in production
  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    // Fetch market data for the selected region
    const fetchMarketData = async () => {
      setLoading(prev => ({ ...prev, marketData: true }));
      try {
        const response = await fetch(`${API_URL}/markets/${activeRegion}`);
        if (!response.ok) throw new Error('Failed to fetch market data');
        const result = await response.json();
        setMarketData(result.data || []);
      } catch (error) {
        console.error('Error fetching market data:', error);
        // Use sample data as fallback
        setMarketData(sampleMarketData[activeRegion] || []);
      } finally {
        setLoading(prev => ({ ...prev, marketData: false }));
      }
    };

    fetchMarketData();
  }, [activeRegion]);

  useEffect(() => {
    // Fetch top gainers
    const fetchGainers = async () => {
      setLoading(prev => ({ ...prev, gainers: true }));
      try {
        const response = await fetch(`${API_URL}/stocks/gainers`);
        if (!response.ok) throw new Error('Failed to fetch gainers');
        const result = await response.json();
        setTopGainers(result.data || []);
      } catch (error) {
        console.error('Error fetching gainers:', error);
        // Use sample data as fallback
        setTopGainers(sampleGainers);
      } finally {
        setLoading(prev => ({ ...prev, gainers: false }));
      }
    };

    // Fetch top losers
    const fetchLosers = async () => {
      setLoading(prev => ({ ...prev, losers: true }));
      try {
        const response = await fetch(`${API_URL}/stocks/losers`);
        if (!response.ok) throw new Error('Failed to fetch losers');
        const result = await response.json();
        setTopLosers(result.data || []);
      } catch (error) {
        console.error('Error fetching losers:', error);
        // Use sample data as fallback
        setTopLosers(sampleLosers);
      } finally {
        setLoading(prev => ({ ...prev, losers: false }));
      }
    };

    // Fetch market news
    const fetchNews = async () => {
      setLoading(prev => ({ ...prev, news: true }));
      try {
        const response = await fetch(`${API_URL}/news`);
        if (!response.ok) throw new Error('Failed to fetch news');
        const result = await response.json();
        setMarketNews(result.data || []);
      } catch (error) {
        console.error('Error fetching news:', error);
        // Use sample data as fallback
        setMarketNews(sampleNews);
      } finally {
        setLoading(prev => ({ ...prev, news: false }));
      }
    };

    fetchGainers();
    fetchLosers();
    fetchNews();
  }, []);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getChangeColor = (change) => {
    return change >= 0 ? 'text-green-600' : 'text-red-600';
  };

  const getChangeBadge = (change) => {
    return change >= 0 ? (
      <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
        <TrendingUp className="h-3 w-3 mr-1" /> {change.toFixed(2)}%
      </Badge>
    ) : (
      <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
        <TrendingDown className="h-3 w-3 mr-1" /> {Math.abs(change).toFixed(2)}%
      </Badge>
    );
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Financial Markets Dashboard</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Market Index Chart */}
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>Market Indices</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="usa" value={activeRegion} onValueChange={setActiveRegion}>
              <TabsList className="mb-4">
                <TabsTrigger value="nepal">Nepal</TabsTrigger>
                <TabsTrigger value="india">India</TabsTrigger>
                <TabsTrigger value="china">China</TabsTrigger>
                <TabsTrigger value="australia">Australia</TabsTrigger>
                <TabsTrigger value="uk">UK</TabsTrigger>
                <TabsTrigger value="usa">USA</TabsTrigger>
              </TabsList>
              
              {loading.marketData ? (
                <div className="h-[300px] flex items-center justify-center">
                  <p>Loading market data...</p>
                </div>
              ) : (
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={marketData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tickFormatter={formatDate}
                      />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`${value}`, 'Index Value']}
                        labelFormatter={(label) => formatDate(label)}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#2563eb" 
                        strokeWidth={2}
                        activeDot={{ r: 8 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
              
              {!loading.marketData && marketData.length > 0 && (
                <div className="mt-4">
                  <h3 className="font-semibold mb-2">Latest: {marketData[marketData.length - 1].value.toFixed(2)}</h3>
                  <div className="flex items-center">
                    <span className={getChangeColor(marketData[marketData.length - 1].change)}>
                      {marketData[marketData.length - 1].change >= 0 ? '+' : ''}
                      {marketData[marketData.length - 1].change.toFixed(2)}
                    </span>
                    <span className="mx-2">|</span>
                    <span className={getChangeColor(marketData[marketData.length - 1].percentChange)}>
                      {marketData[marketData.length - 1].percentChange >= 0 ? '+' : ''}
                      {marketData[marketData.length - 1].percentChange.toFixed(2)}%
                    </span>
                  </div>
                </div>
              )}
            </Tabs>
          </CardContent>
        </Card>

        {/* Market News */}
        <Card>
          <CardHeader>
            <CardTitle>Market News</CardTitle>
          </CardHeader>
          <CardContent>
            {loading.news ? (
              <div className="flex items-center justify-center h-40">
                <p>Loading news...</p>
              </div>
            ) : (
              <div className="space-y-4">
                {marketNews.map((news) => (
                  <div key={news.id} className="border-b pb-3 last:border-0">
                    <div className="flex items-start justify-between">
                      <h3 className="font-medium">{news.title}</h3>
                      {news.importance === 'high' && (
                        <AlertCircle className="h-4 w-4 text-amber-500 flex-shrink-0" />
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{news.summary}</p>
                    <div className="flex justify-between items-center mt-2 text-xs text-gray-500">
                      <span>{news.source}</span>
                      <span>{new Date(news.timestamp).toLocaleTimeString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top Gainers */}
        <Card>
          <CardHeader>
            <CardTitle>Top Gainers</CardTitle>
          </CardHeader>
          <CardContent>
            {loading.gainers ? (
              <div className="flex items-center justify-center h-40">
                <p>Loading gainers...</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Symbol</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Change</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topGainers.map((stock) => (
                    <TableRow key={stock.symbol}>
                      <TableCell className="font-medium">
                        {stock.symbol}
                        <div className="text-xs text-gray-500">{stock.name}</div>
                      </TableCell>
                      <TableCell>${stock.price.toFixed(2)}</TableCell>
                      <TableCell>{getChangeBadge(stock.percentChange)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Top Losers */}
        <Card>
          <CardHeader>
            <CardTitle>Top Losers</CardTitle>
          </CardHeader>
          <CardContent>
            {loading.losers ? (
              <div className="flex items-center justify-center h-40">
                <p>Loading losers...</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Symbol</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Change</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topLosers.map((stock) => (
                    <TableRow key={stock.symbol}>
                      <TableCell className="font-medium">
                        {stock.symbol}
                        <div className="text-xs text-gray-500">{stock.name}</div>
                      </TableCell>
                      <TableCell>${stock.price.toFixed(2)}</TableCell>
                      <TableCell>{getChangeBadge(stock.percentChange)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Sample data for fallback
const sampleMarketData = {
  nepal: [
    { date: '2025-05-01', value: 2145.67, change: 12.45, percentChange: 0.58 },
    { date: '2025-05-02', value: 2156.89, change: 11.22, percentChange: 0.52 },
    { date: '2025-05-03', value: 2178.34, change: 21.45, percentChange: 0.99 },
    { date: '2025-05-04', value: 2165.78, change: -12.56, percentChange: -0.58 },
    { date: '2025-05-05', value: 2189.45, change: 23.67, percentChange: 1.09 },
    { date: '2025-05-06', value: 2201.23, change: 11.78, percentChange: 0.54 },
    { date: '2025-05-07', value: 2215.67, change: 14.44, percentChange: 0.66 },
  ],
  india: [
    { date: '2025-05-01', value: 22456.78, change: 145.67, percentChange: 0.65 },
    { date: '2025-05-02', value: 22567.89, change: 111.11, percentChange: 0.49 },
    { date: '2025-05-03', value: 22789.45, change: 221.56, percentChange: 0.98 },
    { date: '2025-05-04', value: 22678.34, change: -111.11, percentChange: -0.49 },
    { date: '2025-05-05', value: 22890.12, change: 211.78, percentChange: 0.93 },
    { date: '2025-05-06', value: 23012.45, change: 122.33, percentChange: 0.53 },
    { date: '2025-05-07', value: 23145.67, change: 133.22, percentChange: 0.58 },
  ],
  china: [
    { date: '2025-05-01', value: 3456.78, change: 23.45, percentChange: 0.68 },
    { date: '2025-05-02', value: 3478.90, change: 22.12, percentChange: 0.64 },
    { date: '2025-05-03', value: 3512.34, change: 33.44, percentChange: 0.96 },
    { date: '2025-05-04', value: 3489.56, change: -22.78, percentChange: -0.65 },
    { date: '2025-05-05', value: 3523.78, change: 34.22, percentChange: 0.98 },
    { date: '2025-05-06', value: 3545.67, change: 21.89, percentChange: 0.62 },
    { date: '2025-05-07', value: 3578.90, change: 33.23, percentChange: 0.94 },
  ],
  australia: [
    { date: '2025-05-01', value: 7890.45, change: 45.67, percentChange: 0.58 },
    { date: '2025-05-02', value: 7934.56, change: 44.11, percentChange: 0.56 },
    { date: '2025-05-03', value: 7978.90, change: 44.34, percentChange: 0.56 },
    { date: '2025-05-04', value: 7945.67, change: -33.23, percentChange: -0.42 },
    { date: '2025-05-05', value: 7989.34, change: 43.67, percentChange: 0.55 },
    { date: '2025-05-06', value: 8023.56, change: 34.22, percentChange: 0.43 },
    { date: '2025-05-07', value: 8067.89, change: 44.33, percentChange: 0.55 },
  ],
  uk: [
    { date: '2025-05-01', value: 8234.56, change: 56.78, percentChange: 0.69 },
    { date: '2025-05-02', value: 8289.67, change: 55.11, percentChange: 0.67 },
    { date: '2025-05-03', value: 8345.78, change: 56.11, percentChange: 0.68 },
    { date: '2025-05-04', value: 8312.45, change: -33.33, percentChange: -0.40 },
    { date: '2025-05-05', value: 8378.90, change: 66.45, percentChange: 0.80 },
    { date: '2025-05-06', value: 8423.56, change: 44.66, percentChange: 0.53 },
    { date: '2025-05-07', value: 8478.90, change: 55.34, percentChange: 0.66 },
  ],
  usa: [
    { date: '2025-05-01', value: 4567.89, change: 34.56, percentChange: 0.76 },
    { date: '2025-05-02', value: 4598.90, change: 31.01, percentChange: 0.68 },
    { date: '2025-05-03', value: 4634.56, change: 35.66, percentChange: 0.78 },
    { date: '2025-05-04', value: 4612.34, change: -22.22, percentChange: -0.48 },
    { date: '2025-05-05', value: 4645.67, change: 33.33, percentChange: 0.72 },
    { date: '2025-05-06', value: 4678.90, change: 33.23, percentChange: 0.71 },
    { date: '2025-05-07', value: 4712.45, change: 33.55, percentChange: 0.72 },
  ],
};

const sampleGainers = [
  { symbol: 'AAPL', name: 'Apple Inc.', price: 189.45, change: 5.67, percentChange: 3.08 },
  { symbol: 'MSFT', name: 'Microsoft Corp.', price: 412.78, change: 8.90, percentChange: 2.20 },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', price: 178.34, change: 3.45, percentChange: 1.97 },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', price: 189.56, change: 3.67, percentChange: 1.97 },
  { symbol: 'TSLA', name: 'Tesla Inc.', price: 245.67, change: 4.56, percentChange: 1.89 },
];

const sampleLosers = [
  { symbol: 'NKE', name: 'Nike Inc.', price: 98.45, change: -3.56, percentChange: -3.49 },
  { symbol: 'DIS', name: 'Walt Disney Co.', price: 112.34, change: -3.45, percentChange: -2.98 },
  { symbol: 'KO', name: 'Coca-Cola Co.', price: 65.78, change: -1.89, percentChange: -2.79 },
  { symbol: 'PEP', name: 'PepsiCo Inc.', price: 178.90, change: -4.56, percentChange: -2.48 },
  { symbol: 'MCD', name: 'McDonald\'s Corp.', price: 267.89, change: -5.67, percentChange: -2.07 },
];

const sampleNews = [
  {
    id: 1,
    title: 'Central Bank Announces Interest Rate Decision',
    summary: 'The central bank has decided to maintain current interest rates, citing stable inflation and economic growth.',
    source: 'Financial Times',
    timestamp: '2025-06-07T10:30:00Z',
    importance: 'high',
  },
  {
    id: 2,
    title: 'Tech Stocks Rally on Strong Earnings Reports',
    summary: 'Major technology companies reported better-than-expected earnings, driving a sector-wide rally.',
    source: 'Bloomberg',
    timestamp: '2025-06-07T09:15:00Z',
    importance: 'medium',
  },
  {
    id: 3,
    title: 'Oil Prices Stabilize After Recent Volatility',
    summary: 'Global oil prices have stabilized following a period of significant volatility due to geopolitical tensions.',
    source: 'Reuters',
    timestamp: '2025-06-07T08:45:00Z',
    importance: 'medium',
  },
  {
    id: 4,
    title: 'New Regulatory Framework for Cryptocurrency Announced',
    summary: 'Regulators have unveiled a comprehensive framework for cryptocurrency oversight, bringing clarity to the market.',
    source: 'CoinDesk',
    timestamp: '2025-06-07T07:30:00Z',
    importance: 'high',
  },
  {
    id: 5,
    title: 'Manufacturing Sector Shows Signs of Recovery',
    summary: 'Recent data indicates a recovery in the manufacturing sector, with increased production and new orders.',
    source: 'Economic Times',
    timestamp: '2025-06-07T06:15:00Z',
    importance: 'medium',
  },
];

export default MarketDashboard;

