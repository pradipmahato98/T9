import { useState, useCallback } from 'react';

export function useToast() {
  const [toast, setToast] = useState(null);

  const showToast = useCallback(({ title, description, variant = "default", duration = 3000 }) => {
    setToast({ title, description, variant });
    
    setTimeout(() => {
      setToast(null);
    }, duration);
  }, []);

  return {
    toast,
    showToast,
  };
}

