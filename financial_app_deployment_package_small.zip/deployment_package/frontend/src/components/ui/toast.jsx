import React from 'react';
import { useToast } from './use-toast';

export function Toast({ title, description, variant = "default" }) {
  return (
    <div className={`fixed bottom-4 right-4 p-4 rounded-md shadow-md ${
      variant === "destructive" ? "bg-red-100 border-red-400" : "bg-white border-gray-200"
    } border`}>
      {title && <h3 className="font-medium">{title}</h3>}
      {description && <p className="text-sm text-gray-600">{description}</p>}
    </div>
  );
}

export function Toaster() {
  const { toast } = useToast();
  
  return (
    <div className="fixed bottom-4 right-4 z-50">
      {toast && <Toast {...toast} />}
    </div>
  );
}

