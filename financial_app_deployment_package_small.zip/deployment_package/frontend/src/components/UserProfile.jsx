import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Bell, Shield, Key, Globe, Eye, EyeOff, User, Settings, LogOut } from 'lucide-react';
import { useToast } from "./ui/use-toast.jsx";

const UserProfile = () => {
  const [user, setUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const { toast } = useToast();

  // Backend API URL - will be replaced with environment variable in production
  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
  
  // User ID - in a real app, this would come from authentication context
  const USER_ID = '12345';

  useEffect(() => {
    const fetchUserData = async () => {
      setLoading(true);
      try {
        const response = await fetch(`${API_URL}/users/${USER_ID}`);
        if (!response.ok) throw new Error('Failed to fetch user data');
        const result = await response.json();
        
        if (result.status === 'success' && result.data) {
          setUser(result.data);
          setFormData({
            ...formData,
            fullName: result.data.fullName,
            email: result.data.email,
          });
        } else {
          throw new Error('Invalid user data received');
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        // Use sample data as fallback
        setUser(sampleUserData);
        setFormData({
          ...formData,
          fullName: sampleUserData.fullName,
          email: sampleUserData.email,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleToggleChange = (key, subKey = null) => {
    if (!user) return;
    
    if (subKey) {
      setUser({
        ...user,
        preferences: {
          ...user.preferences,
          [key]: {
            ...user.preferences[key],
            [subKey]: !user.preferences[key][subKey],
          },
        },
      });
    } else {
      setUser({
        ...user,
        preferences: {
          ...user.preferences,
          [key]: !user.preferences[key],
        },
      });
    }
  };

  const handleSelectChange = (key, value) => {
    if (!user) return;
    
    setUser({
      ...user,
      preferences: {
        ...user.preferences,
        [key]: value,
      },
    });
  };

  const handleSaveProfile = async () => {
    try {
      // In a real application, this would send data to an API
      const response = await fetch(`${API_URL}/users/${USER_ID}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fullName: formData.fullName,
          email: formData.email,
        }),
      });
      
      if (!response.ok) throw new Error('Failed to update profile');
      
      const result = await response.json();
      if (result.status === 'success') {
        setUser({
          ...user,
          fullName: formData.fullName,
          email: formData.email,
        });
        
        toast({
          title: "Profile Updated",
          description: "Your profile has been updated successfully.",
        });
      } else {
        throw new Error(result.message || 'Failed to update profile');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      toast({
        title: "Update Failed",
        description: "There was a problem updating your profile. Please try again.",
        variant: "destructive",
      });
      
      // Simulate successful update for demo purposes
      setUser({
        ...user,
        fullName: formData.fullName,
        email: formData.email,
      });
    }
    
    setIsEditing(false);
  };

  const handleChangePassword = async () => {
    // Validate passwords
    if (formData.newPassword !== formData.confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "New password and confirmation do not match.",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.newPassword.length < 8) {
      toast({
        title: "Password Too Short",
        description: "Password must be at least 8 characters long.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // In a real application, this would send data to an API
      // Simulating API call for demo purposes
      toast({
        title: "Password Changed",
        description: "Your password has been updated successfully.",
      });
      
      setFormData({
        ...formData,
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
    } catch (error) {
      toast({
        title: "Password Change Failed",
        description: "There was a problem changing your password. Please try again.",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 flex items-center justify-center h-screen">
        <p>Loading user profile...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto p-4 flex items-center justify-center h-screen">
        <p>Failed to load user profile. Please try again later.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="w-full md:w-1/4">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center space-y-4">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={user.profileImage} alt={user.fullName} />
                  <AvatarFallback>{user.fullName.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h2 className="text-xl font-bold">{user.fullName}</h2>
                  <p className="text-gray-500">@{user.username}</p>
                  <Badge className="mt-2" variant="outline">
                    {user.accountType.charAt(0).toUpperCase() + user.accountType.slice(1)} Account
                  </Badge>
                </div>
              </div>
              
              <div className="mt-6 space-y-2">
                <Button variant="ghost" className="w-full justify-start">
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Settings className="mr-2 h-4 w-4" />
                  Preferences
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Shield className="mr-2 h-4 w-4" />
                  Security
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Bell className="mr-2 h-4 w-4" />
                  Notifications
                </Button>
                <Button variant="ghost" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50">
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </Button>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="text-sm text-gray-500">
                  <p>Member since: {new Date(user.joinDate).toLocaleDateString()}</p>
                  <p>Last login: {new Date(user.lastLogin).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Main Content */}
        <div className="w-full md:w-3/4">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
            </TabsList>
            
            {/* Profile Tab */}
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>
                    Manage your personal information and account details
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      value={user.username}
                      disabled
                    />
                    <p className="text-xs text-gray-500">Username cannot be changed</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountType">Account Type</Label>
                    <Input
                      id="accountType"
                      value={user.accountType.charAt(0).toUpperCase() + user.accountType.slice(1)}
                      disabled
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  {isEditing ? (
                    <>
                      <Button variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
                      <Button onClick={handleSaveProfile}>Save Changes</Button>
                    </>
                  ) : (
                    <Button onClick={() => setIsEditing(true)}>Edit Profile</Button>
                  )}
                </CardFooter>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Change Password</CardTitle>
                  <CardDescription>
                    Update your password to keep your account secure
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <div className="relative">
                      <Input
                        id="currentPassword"
                        name="currentPassword"
                        type={showPassword ? "text" : "password"}
                        value={formData.currentPassword}
                        onChange={handleInputChange}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <div className="relative">
                      <Input
                        id="newPassword"
                        name="newPassword"
                        type={showPassword ? "text" : "password"}
                        value={formData.newPassword}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type={showPassword ? "text" : "password"}
                        value={formData.confirmPassword}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleChangePassword}>Change Password</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Preferences Tab */}
            <TabsContent value="preferences">
              <Card>
                <CardHeader>
                  <CardTitle>Application Preferences</CardTitle>
                  <CardDescription>
                    Customize your experience with the application
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Regional Settings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="defaultRegion">Default Region</Label>
                        <Select 
                          value={user.preferences.defaultRegion} 
                          onValueChange={(value) => handleSelectChange('defaultRegion', value)}
                        >
                          <SelectTrigger id="defaultRegion">
                            <SelectValue placeholder="Select a region" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="nepal">Nepal</SelectItem>
                            <SelectItem value="india">India</SelectItem>
                            <SelectItem value="china">China</SelectItem>
                            <SelectItem value="australia">Australia</SelectItem>
                            <SelectItem value="uk">UK</SelectItem>
                            <SelectItem value="usa">USA</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="language">Language</Label>
                        <Select 
                          value={user.preferences.language} 
                          onValueChange={(value) => handleSelectChange('language', value)}
                        >
                          <SelectTrigger id="language">
                            <SelectValue placeholder="Select a language" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en">English</SelectItem>
                            <SelectItem value="ne">Nepali</SelectItem>
                            <SelectItem value="hi">Hindi</SelectItem>
                            <SelectItem value="zh">Chinese</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Display Settings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="theme">Theme</Label>
                        <Select 
                          value={user.preferences.theme} 
                          onValueChange={(value) => handleSelectChange('theme', value)}
                        >
                          <SelectTrigger id="theme">
                            <SelectValue placeholder="Select a theme" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="light">Light</SelectItem>
                            <SelectItem value="dark">Dark</SelectItem>
                            <SelectItem value="system">System</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="defaultLandingPage">Default Landing Page</Label>
                        <Select 
                          value={user.preferences.defaultLandingPage} 
                          onValueChange={(value) => handleSelectChange('defaultLandingPage', value)}
                        >
                          <SelectTrigger id="defaultLandingPage">
                            <SelectValue placeholder="Select a page" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="dashboard">Dashboard</SelectItem>
                            <SelectItem value="markets">Markets</SelectItem>
                            <SelectItem value="portfolio">Portfolio</SelectItem>
                            <SelectItem value="news">News</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Data Settings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="dataRefreshRate">Data Refresh Rate</Label>
                        <Select 
                          value={user.preferences.dataRefreshRate} 
                          onValueChange={(value) => handleSelectChange('dataRefreshRate', value)}
                        >
                          <SelectTrigger id="dataRefreshRate">
                            <SelectValue placeholder="Select refresh rate" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="10s">10 seconds</SelectItem>
                            <SelectItem value="30s">30 seconds</SelectItem>
                            <SelectItem value="1m">1 minute</SelectItem>
                            <SelectItem value="5m">5 minutes</SelectItem>
                            <SelectItem value="manual">Manual refresh only</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={() => {
                    toast({
                      title: "Preferences Saved",
                      description: "Your preferences have been updated successfully.",
                    });
                  }}>Save Preferences</Button>
                </CardFooter>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <CardDescription>
                    Manage how and when you receive notifications
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Notification Channels</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="emailNotifications">Email Notifications</Label>
                          <p className="text-sm text-gray-500">Receive notifications via email</p>
                        </div>
                        <Switch
                          id="emailNotifications"
                          checked={user.preferences.notifications.email}
                          onCheckedChange={() => handleToggleChange('notifications', 'email')}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="pushNotifications">Push Notifications</Label>
                          <p className="text-sm text-gray-500">Receive notifications on your device</p>
                        </div>
                        <Switch
                          id="pushNotifications"
                          checked={user.preferences.notifications.push}
                          onCheckedChange={() => handleToggleChange('notifications', 'push')}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="smsNotifications">SMS Notifications</Label>
                          <p className="text-sm text-gray-500">Receive notifications via SMS</p>
                        </div>
                        <Switch
                          id="smsNotifications"
                          checked={user.preferences.notifications.sms}
                          onCheckedChange={() => handleToggleChange('notifications', 'sms')}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Notification Types</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="priceAlerts">Price Alerts</Label>
                          <p className="text-sm text-gray-500">Notifications for price movements</p>
                        </div>
                        <Switch
                          id="priceAlerts"
                          checked={user.preferences.notifications.priceAlerts}
                          onCheckedChange={() => handleToggleChange('notifications', 'priceAlerts')}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="newsAlerts">News Alerts</Label>
                          <p className="text-sm text-gray-500">Notifications for important news</p>
                        </div>
                        <Switch
                          id="newsAlerts"
                          checked={user.preferences.notifications.newsAlerts}
                          onCheckedChange={() => handleToggleChange('notifications', 'newsAlerts')}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="portfolioUpdates">Portfolio Updates</Label>
                          <p className="text-sm text-gray-500">Notifications for portfolio changes</p>
                        </div>
                        <Switch
                          id="portfolioUpdates"
                          checked={user.preferences.notifications.portfolioUpdates}
                          onCheckedChange={() => handleToggleChange('notifications', 'portfolioUpdates')}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={() => {
                    toast({
                      title: "Notification Settings Saved",
                      description: "Your notification preferences have been updated successfully.",
                    });
                  }}>Save Notification Settings</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Security Tab */}
            <TabsContent value="security">
              <Card>
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>
                    Manage your account security and authentication options
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="twoFactorAuth">Enable Two-Factor Authentication</Label>
                        <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
                      </div>
                      <Switch
                        id="twoFactorAuth"
                        checked={user.security.twoFactorEnabled}
                        onCheckedChange={() => {
                          setUser({
                            ...user,
                            security: {
                              ...user.security,
                              twoFactorEnabled: !user.security.twoFactorEnabled,
                            },
                          });
                        }}
                      />
                    </div>
                    {user.security.twoFactorEnabled && (
                      <div className="mt-4 p-4 bg-gray-50 rounded-md">
                        <p className="text-sm">Two-factor authentication is enabled. You'll be asked for a verification code when signing in from new devices.</p>
                        <Button variant="outline" size="sm" className="mt-2">
                          <Key className="mr-2 h-4 w-4" />
                          Manage 2FA Settings
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Password Security</h3>
                    <div className="space-y-2">
                      <p className="text-sm">Last password change: {formatDate(user.security.lastPasswordChange)}</p>
                      <Button variant="outline">
                        Change Password
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Login History</h3>
                    <div className="border rounded-md">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Device</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {user.security.loginHistory.map((login, index) => (
                            <tr key={index}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {formatDate(login.date)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {login.device}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {login.location}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm">
                                {login.status === 'success' ? (
                                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Success</Badge>
                                ) : (
                                  <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Failed</Badge>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Account Actions</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="text-amber-600 border-amber-600 hover:bg-amber-50" onClick={() => {
                        toast({
                          title: "Sign Out Initiated",
                          description: "You have been signed out from all devices.",
                        });
                      }}>
                        <Globe className="mr-2 h-4 w-4" />
                        Sign Out of All Devices
                      </Button>
                      <Button variant="outline" className="text-red-600 border-red-600 hover:bg-red-50" onClick={() => {
                        toast({
                          title: "Account Locked",
                          description: "Your account has been locked. Please contact support to unlock it.",
                          variant: "destructive",
                        });
                      }}>
                        <Shield className="mr-2 h-4 w-4" />
                        Lock Account
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

// Sample user data for fallback
const sampleUserData = {
  id: "12345",
  username: "investor2025",
  email: "investor@example.com",
  fullName: "Alex Johnson",
  profileImage: "https://i.pravatar.cc/300",
  accountType: "premium",
  joinDate: "2024-01-15T00:00:00Z",
  lastLogin: "2025-06-06T14:30:00Z",
  preferences: {
    defaultRegion: "usa",
    theme: "system",
    language: "en",
    notifications: {
      email: true,
      push: true,
      sms: false,
      priceAlerts: true,
      newsAlerts: true,
      portfolioUpdates: true,
    },
    defaultLandingPage: "dashboard",
    dataRefreshRate: "30s",
  },
  security: {
    twoFactorEnabled: true,
    lastPasswordChange: "2025-04-10T00:00:00Z",
    loginHistory: [
      { date: "2025-06-06T14:30:00Z", device: "Chrome / Windows", location: "New York, USA", status: "success" },
      { date: "2025-06-05T09:15:00Z", device: "Safari / macOS", location: "New York, USA", status: "success" },
      { date: "2025-06-03T18:45:00Z", device: "Firefox / Linux", location: "Boston, USA", status: "success" },
      { date: "2025-06-01T11:20:00Z", device: "Chrome / Android", location: "Chicago, USA", status: "success" },
      { date: "2025-05-28T16:05:00Z", device: "Chrome / Windows", location: "Seattle, USA", status: "failed" },
    ],
  },
};

export default UserProfile;

