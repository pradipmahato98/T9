# Backend Deployment Guide: Render/Fly.io

This guide provides step-by-step instructions for deploying the Financial Markets Web Application backend to either Render or Fly.io. Both platforms offer generous free tiers suitable for this application.

## Option 1: Deploying to Render

### Prerequisites
- A GitHub, GitLab, or Bitbucket account with your project repository
- A Render account (you can sign up at [render.com](https://render.com))

### Step 1: Sign Up for Render
1. Go to [render.com](https://render.com)
2. Click "Sign Up" and choose to sign up with GitHub, GitLab, or email
3. Follow the prompts to complete the sign-up process

### Step 2: Create a New Web Service
1. From the Render dashboard, click "New" and select "Web Service"
2. Connect to your Git provider if not already connected
3. Select the repository containing your backend code

### Step 3: Configure Web Service
1. Configure the service with the following settings:
   - **Name**: Choose a name for your service (e.g., `financial-backend`)
   - **Runtime**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn src.main:app`
   - **Root Directory**: `/financial_app_poc/backend/financial_backend` (adjust if your repository structure is different)

2. Select the appropriate plan (Free tier is sufficient for development and testing)

3. Add the following environment variables:
   - **Key**: `PORT`
   - **Value**: `10000` (Render will automatically assign a port, but this is a fallback)
   
   - **Key**: `FLASK_ENV`
   - **Value**: `production`
   
   - **Key**: `CORS_ALLOWED_ORIGINS`
   - **Value**: Your frontend URL (e.g., `https://financial-frontend.netlify.app`)

4. Click "Create Web Service"

### Step 4: Monitor Deployment
1. Render will build and deploy your application
2. You can monitor the build and deployment process in real-time
3. Once complete, Render will provide a URL for your deployed application (e.g., `https://financial-backend.onrender.com`)

### Step 5: Test the Deployment
1. Visit the provided URL in your browser (e.g., `https://financial-backend.onrender.com`)
2. You should see the API welcome message
3. Test specific endpoints (e.g., `https://financial-backend.onrender.com/api/markets/usa`)

### Step 6: Update Frontend Configuration
1. Update your frontend's environment variable `VITE_API_URL` to point to your new backend URL
2. Redeploy your frontend if necessary

## Option 2: Deploying to Fly.io

### Prerequisites
- A GitHub account with your project repository
- A Fly.io account (you can sign up at [fly.io](https://fly.io))
- Fly CLI installed on your local machine

### Step 1: Sign Up for Fly.io
1. Go to [fly.io](https://fly.io)
2. Click "Sign Up" and follow the prompts to create an account
3. Add a credit card (required even for free tier, but you won't be charged for small apps)

### Step 2: Install Fly CLI
1. Install the Fly CLI by following the instructions at [fly.io/docs/hands-on/install-flyctl/](https://fly.io/docs/hands-on/install-flyctl/)
2. Open a terminal and run `flyctl auth login` to authenticate

### Step 3: Prepare Your Application
1. Navigate to your backend directory:
   ```
   cd /financial_app_poc/backend/financial_backend
   ```

2. Create a `fly.toml` file in your project root:
   ```toml
   app = "financial-backend"
   primary_region = "iad"  # Choose a region close to your users

   [build]
     builder = "paketobuildpacks/builder:base"

   [env]
     PORT = "8080"
     FLASK_ENV = "production"

   [http_service]
     internal_port = 8080
     force_https = true
     auto_stop_machines = true
     auto_start_machines = true
     min_machines_running = 0
     processes = ["app"]
   ```

### Step 4: Deploy Your Application
1. Initialize your Fly.io application:
   ```
   flyctl launch --no-deploy
   ```

2. Set environment variables:
   ```
   flyctl secrets set CORS_ALLOWED_ORIGINS=https://financial-frontend.netlify.app
   ```

3. Deploy your application:
   ```
   flyctl deploy
   ```

### Step 5: Monitor Deployment
1. Fly.io will build and deploy your application
2. You can monitor the deployment with:
   ```
   flyctl status
   ```

3. Once complete, Fly.io will provide a URL for your deployed application (e.g., `https://financial-backend.fly.dev`)

### Step 6: Test the Deployment
1. Visit the provided URL in your browser
2. You should see the API welcome message
3. Test specific endpoints (e.g., `https://financial-backend.fly.dev/api/markets/usa`)

### Step 7: Update Frontend Configuration
1. Update your frontend's environment variable `VITE_API_URL` to point to your new backend URL
2. Redeploy your frontend if necessary

## Troubleshooting Common Issues

### Build Failures
- **Issue**: Build fails due to missing dependencies
  - **Solution**: Ensure all dependencies are listed in `requirements.txt`

- **Issue**: Python version mismatch
  - **Solution**: Specify the correct Python version in `runtime.txt`

### Application Errors
- **Issue**: Application crashes on startup
  - **Solution**: Check the logs for error messages and ensure your start command is correct

- **Issue**: Database connection errors
  - **Solution**: Ensure your database connection string is correctly set in environment variables

### CORS Issues
- **Issue**: Frontend cannot access backend due to CORS errors
  - **Solution**: Ensure CORS is properly configured in your Flask application and the allowed origins include your frontend domain

## Maintaining Your Deployment

### Continuous Deployment
Both Render and Fly.io support continuous deployment. When you push changes to your repository, your application will automatically rebuild and deploy.

### Scaling
- **Render**: Upgrade to a paid plan for more resources and better performance
- **Fly.io**: Use `flyctl scale` to adjust the resources allocated to your application

### Monitoring
Both platforms provide basic monitoring:
- **Render**: Check the "Logs" tab in your service dashboard
- **Fly.io**: Use `flyctl logs` to view application logs

### Database Considerations
For a production application, consider adding a managed database:
- **Render**: Offers PostgreSQL databases with a free tier
- **Fly.io**: Offers PostgreSQL databases with a free tier (limited storage)

## Cost Considerations

### Render Free Tier Limitations
- Free web services spin down after 15 minutes of inactivity
- Spin-up can take 30+ seconds when a request comes in after inactivity
- 750 hours of runtime per month
- Limited to 512 MB RAM and shared CPU

### Fly.io Free Tier Limitations
- 3 shared-cpu-1x 256MB VMs
- 3GB persistent volume storage
- 160GB outbound data transfer

