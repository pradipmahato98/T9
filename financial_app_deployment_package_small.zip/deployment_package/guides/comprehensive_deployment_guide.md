# Financial Markets Web Application
## Comprehensive Deployment Guide

**Author: Manus AI**  
**Date: June 7, 2025**

---

## Table of Contents

1. [Introduction](#introduction)
2. [Project Overview](#project-overview)
3. [Local Development Setup](#local-development-setup)
4. [Frontend Deployment (Vercel/Netlify)](#frontend-deployment-vercelnelify)
5. [Backend Deployment (Render/Fly.io)](#backend-deployment-renderfly.io)
6. [Integration and Testing](#integration-and-testing)
7. [Maintenance and Monitoring](#maintenance-and-monitoring)
8. [Troubleshooting](#troubleshooting)
9. [Security Considerations](#security-considerations)
10. [Future Enhancements](#future-enhancements)

---

## Introduction

This comprehensive guide provides detailed instructions for deploying the Financial Markets Web Application. The application consists of a React frontend and a Flask backend, which will be deployed to separate platforms to leverage their free tiers while maintaining a modern architecture.

The deployment strategy uses:
- **Frontend**: Vercel or Netlify (both offer generous free tiers for static sites)
- **Backend**: Render or Fly.io (both offer free tiers for backend services)

This approach allows for a cost-effective deployment while maintaining scalability and performance.

---

## Project Overview

The Financial Markets Web Application is a comprehensive platform for tracking and analyzing financial markets across multiple regions (Nepal, India, China, Australia, UK, and USA). It includes features for:

- Market data visualization
- Stock tracking
- Financial news aggregation
- User profiles and preferences
- Admin panel for system management
- Developer tools with AI-assisted features

The application is built with:
- **Frontend**: React, Vite, TailwindCSS
- **Backend**: Flask, Flask-CORS, Gunicorn

---

## Local Development Setup

### Prerequisites
- Node.js (v20.18.0 or later)
- Python (v3.11.0 or later)
- npm or yarn package manager

### Frontend Setup
1. Navigate to the frontend directory:
   ```bash
   cd /financial_app_poc/frontend/financial-frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file with the backend URL:
   ```
   VITE_API_URL=http://localhost:5000/api
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

5. The frontend will be available at `http://localhost:5173`

### Backend Setup
1. Navigate to the backend directory:
   ```bash
   cd /financial_app_poc/backend/financial_backend
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Start the development server:
   ```bash
   python src/main.py
   ```

5. The backend will be available at `http://localhost:5000`

---

## Frontend Deployment (Vercel/Netlify)

### Option 1: Deploying to Vercel

#### Prerequisites
- A GitHub, GitLab, or Bitbucket account with your project repository
- A Vercel account (you can sign up at [vercel.com](https://vercel.com))

#### Step 1: Sign Up for Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "Sign Up" and choose to sign up with GitHub, GitLab, Bitbucket, or email
3. Follow the prompts to complete the sign-up process

#### Step 2: Import Your Project
1. From the Vercel dashboard, click "Add New..." and select "Project"
2. Connect to your Git provider if not already connected
3. Select the repository containing your frontend code
4. Vercel will automatically detect that it's a Vite/React project

#### Step 3: Configure Project Settings
1. Configure the project with the following settings:
   - **Framework Preset**: Vite
   - **Root Directory**: `/financial_app_poc/frontend/financial-frontend` (adjust if your repository structure is different)
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`

2. Add the following environment variable:
   - **Name**: `VITE_API_URL`
   - **Value**: Your backend API URL (e.g., `https://financial-backend.onrender.com/api`)

3. Click "Deploy"

#### Step 4: Monitor Deployment
1. Vercel will build and deploy your application
2. You can monitor the build process in real-time
3. Once complete, Vercel will provide a URL for your deployed application

#### Step 5: Configure Custom Domain (Optional)
1. From your project dashboard, go to "Settings" > "Domains"
2. Add your custom domain and follow the verification steps
3. Update your DNS settings as instructed by Vercel

### Option 2: Deploying to Netlify

#### Prerequisites
- A GitHub, GitLab, or Bitbucket account with your project repository
- A Netlify account (you can sign up at [netlify.com](https://netlify.com))

#### Step 1: Sign Up for Netlify
1. Go to [netlify.com](https://netlify.com)
2. Click "Sign Up" and choose to sign up with GitHub, GitLab, Bitbucket, or email
3. Follow the prompts to complete the sign-up process

#### Step 2: Import Your Project
1. From the Netlify dashboard, click "Add new site" > "Import an existing project"
2. Connect to your Git provider if not already connected
3. Select the repository containing your frontend code

#### Step 3: Configure Build Settings
1. Configure the build settings:
   - **Base directory**: `/financial_app_poc/frontend/financial-frontend` (adjust if your repository structure is different)
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`

2. Add the following environment variable:
   - **Key**: `VITE_API_URL`
   - **Value**: Your backend API URL (e.g., `https://financial-backend.onrender.com/api`)

3. Click "Deploy site"

#### Step 4: Monitor Deployment
1. Netlify will build and deploy your application
2. You can monitor the build process in the "Deploys" tab
3. Once complete, Netlify will provide a URL for your deployed application

#### Step 5: Configure Custom Domain (Optional)
1. From your site dashboard, go to "Site settings" > "Domain management"
2. Click "Add custom domain" and follow the verification steps
3. Update your DNS settings as instructed by Netlify

---

## Backend Deployment (Render/Fly.io)

### Option 1: Deploying to Render

#### Prerequisites
- A GitHub, GitLab, or Bitbucket account with your project repository
- A Render account (you can sign up at [render.com](https://render.com))

#### Step 1: Sign Up for Render
1. Go to [render.com](https://render.com)
2. Click "Sign Up" and choose to sign up with GitHub, GitLab, or email
3. Follow the prompts to complete the sign-up process

#### Step 2: Create a New Web Service
1. From the Render dashboard, click "New" and select "Web Service"
2. Connect to your Git provider if not already connected
3. Select the repository containing your backend code

#### Step 3: Configure Web Service
1. Configure the service with the following settings:
   - **Name**: Choose a name for your service (e.g., `financial-backend`)
   - **Runtime**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn src.main:app`
   - **Root Directory**: `/financial_app_poc/backend/financial_backend` (adjust if your repository structure is different)

2. Select the appropriate plan (Free tier is sufficient for development and testing)

3. Add the following environment variables:
   - **Key**: `PORT`
   - **Value**: `10000` (Render will automatically assign a port, but this is a fallback)
   
   - **Key**: `FLASK_ENV`
   - **Value**: `production`
   
   - **Key**: `CORS_ALLOWED_ORIGINS`
   - **Value**: Your frontend URL (e.g., `https://financial-frontend.netlify.app`)

4. Click "Create Web Service"

#### Step 4: Monitor Deployment
1. Render will build and deploy your application
2. You can monitor the build and deployment process in real-time
3. Once complete, Render will provide a URL for your deployed application (e.g., `https://financial-backend.onrender.com`)

#### Step 5: Test the Deployment
1. Visit the provided URL in your browser (e.g., `https://financial-backend.onrender.com`)
2. You should see the API welcome message
3. Test specific endpoints (e.g., `https://financial-backend.onrender.com/api/markets/usa`)

### Option 2: Deploying to Fly.io

#### Prerequisites
- A GitHub account with your project repository
- A Fly.io account (you can sign up at [fly.io](https://fly.io))
- Fly CLI installed on your local machine

#### Step 1: Sign Up for Fly.io
1. Go to [fly.io](https://fly.io)
2. Click "Sign Up" and follow the prompts to create an account
3. Add a credit card (required even for free tier, but you won't be charged for small apps)

#### Step 2: Install Fly CLI
1. Install the Fly CLI by following the instructions at [fly.io/docs/hands-on/install-flyctl/](https://fly.io/docs/hands-on/install-flyctl/)
2. Open a terminal and run `flyctl auth login` to authenticate

#### Step 3: Prepare Your Application
1. Navigate to your backend directory:
   ```
   cd /financial_app_poc/backend/financial_backend
   ```

2. Create a `fly.toml` file in your project root:
   ```toml
   app = "financial-backend"
   primary_region = "iad"  # Choose a region close to your users

   [build]
     builder = "paketobuildpacks/builder:base"

   [env]
     PORT = "8080"
     FLASK_ENV = "production"

   [http_service]
     internal_port = 8080
     force_https = true
     auto_stop_machines = true
     auto_start_machines = true
     min_machines_running = 0
     processes = ["app"]
   ```

#### Step 4: Deploy Your Application
1. Initialize your Fly.io application:
   ```
   flyctl launch --no-deploy
   ```

2. Set environment variables:
   ```
   flyctl secrets set CORS_ALLOWED_ORIGINS=https://financial-frontend.netlify.app
   ```

3. Deploy your application:
   ```
   flyctl deploy
   ```

#### Step 5: Monitor Deployment
1. Fly.io will build and deploy your application
2. You can monitor the deployment with:
   ```
   flyctl status
   ```

3. Once complete, Fly.io will provide a URL for your deployed application (e.g., `https://financial-backend.fly.dev`)

---

## Integration and Testing

### Updating Frontend Configuration
After deploying your backend, you need to update your frontend to use the deployed backend API:

1. Go to your frontend deployment platform (Vercel or Netlify)
2. Navigate to the environment variables section
3. Update the `VITE_API_URL` variable to point to your deployed backend URL
4. Trigger a new deployment of your frontend

### Testing the Integration
1. Open your deployed frontend application in a browser
2. Verify that market data is loading correctly
3. Test user profile functionality
4. Ensure all API requests are successful (check browser developer tools)

### Common Integration Issues
1. **CORS Errors**: If you see CORS errors in the browser console, ensure your backend has the correct CORS configuration with your frontend domain as an allowed origin.

2. **API Endpoint Mismatches**: Ensure your frontend is using the correct API endpoints that match your backend implementation.

3. **Environment Variable Issues**: Verify that environment variables are correctly set and accessible in your application.

---

## Maintenance and Monitoring

### Continuous Deployment
Both frontend and backend platforms support continuous deployment from your Git repository. When you push changes:

1. The platform will automatically detect the changes
2. A new build will be triggered
3. If the build succeeds, the new version will be deployed

### Monitoring
Monitor your application's performance and usage:

#### Frontend Monitoring
- **Vercel**: Use the Analytics tab in your project dashboard
- **Netlify**: Use the Analytics tab in your site dashboard

#### Backend Monitoring
- **Render**: Check the Logs tab in your service dashboard
- **Fly.io**: Use `flyctl logs` to view application logs

### Scaling Considerations
As your application grows, you may need to scale:

#### Frontend Scaling
Static sites on Vercel and Netlify scale automatically with CDN distribution.

#### Backend Scaling
- **Render**: Upgrade to a paid plan for more resources
- **Fly.io**: Use `flyctl scale` to adjust resources

---

## Troubleshooting

### Frontend Issues

#### Build Failures
- **Issue**: Build fails due to missing dependencies
  - **Solution**: Ensure all dependencies are listed in `package.json` and run `npm install` locally to verify

- **Issue**: Environment variables not accessible in the application
  - **Solution**: Ensure environment variables are prefixed with `VITE_` for Vite to expose them to the frontend

#### Routing Issues
- **Issue**: 404 errors when refreshing pages with client-side routing
  - **Solution**: Add a `_redirects` file (Netlify) or `vercel.json` configuration (Vercel) to handle SPA routing

### Backend Issues

#### Build Failures
- **Issue**: Build fails due to missing dependencies
  - **Solution**: Ensure all dependencies are listed in `requirements.txt`

- **Issue**: Python version mismatch
  - **Solution**: Specify the correct Python version in `runtime.txt`

#### Application Errors
- **Issue**: Application crashes on startup
  - **Solution**: Check the logs for error messages and ensure your start command is correct

#### CORS Issues
- **Issue**: Frontend cannot access backend due to CORS errors
  - **Solution**: Ensure CORS is properly configured in your Flask application and the allowed origins include your frontend domain

---

## Security Considerations

### Authentication
The current implementation includes a basic authentication system. For production use, consider:

1. Implementing JWT-based authentication
2. Adding OAuth providers (Google, GitHub, etc.)
3. Implementing rate limiting for API endpoints

### Data Protection
1. Ensure sensitive data is not exposed in API responses
2. Implement proper input validation on all API endpoints
3. Consider encrypting sensitive data in the database

### HTTPS
Both frontend and backend platforms provide HTTPS by default. Ensure:

1. All API requests use HTTPS
2. All external resources are loaded over HTTPS
3. Implement proper HSTS headers

---

## Future Enhancements

### Technical Enhancements
1. Add a proper database (PostgreSQL, MongoDB)
2. Implement caching for API responses
3. Add comprehensive test coverage
4. Implement CI/CD pipelines

### Feature Enhancements
1. Real-time market data updates
2. Advanced charting capabilities
3. Portfolio tracking and management
4. Mobile application version

---

## Conclusion

This guide has provided comprehensive instructions for deploying the Financial Markets Web Application using free tier services from Vercel/Netlify for the frontend and Render/Fly.io for the backend. By following these steps, you can have a fully functional application deployed to the internet with minimal cost.

For production use, consider the security enhancements and scaling options mentioned in this guide. As your application grows, you may need to upgrade to paid plans or explore other hosting options.

---

## Appendix: Environment Variables Reference

### Frontend Environment Variables

| Variable | Description | Example Value |
|----------|-------------|---------------|
| `VITE_API_URL` | URL of the backend API | `https://financial-backend.onrender.com/api` |

### Backend Environment Variables

| Variable | Description | Example Value |
|----------|-------------|---------------|
| `PORT` | Port on which the application will run | `8000` |
| `FLASK_ENV` | Flask environment (production/development) | `production` |
| `FLASK_APP` | Flask application entry point | `src.main:app` |
| `CORS_ALLOWED_ORIGINS` | Comma-separated list of allowed origins for CORS | `https://financial-frontend.netlify.app` |

