# Frontend Deployment Guide: Vercel/Netlify

This guide provides step-by-step instructions for deploying the Financial Markets Web Application frontend to either Vercel or Netlify. Both platforms offer generous free tiers suitable for this application.

## Option 1: Deploying to Vercel

### Prerequisites
- A GitHub, GitLab, or Bitbucket account with your project repository
- A Vercel account (you can sign up at [vercel.com](https://vercel.com))

### Step 1: Sign Up for Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "Sign Up" and choose to sign up with GitHub, GitLab, Bitbucket, or email
3. Follow the prompts to complete the sign-up process

### Step 2: Import Your Project
1. From the Vercel dashboard, click "Add New..." and select "Project"
2. Connect to your Git provider if not already connected
3. Select the repository containing your frontend code
4. Vercel will automatically detect that it's a Vite/React project

### Step 3: Configure Project Settings
1. Configure the project with the following settings:
   - **Framework Preset**: Vite
   - **Root Directory**: `/financial_app_poc/frontend/financial-frontend` (adjust if your repository structure is different)
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`

2. Add the following environment variable:
   - **Name**: `VITE_API_URL`
   - **Value**: Your backend API URL (e.g., `https://financial-backend.onrender.com/api`)

3. Click "Deploy"

### Step 4: Monitor Deployment
1. Vercel will build and deploy your application
2. You can monitor the build process in real-time
3. Once complete, Vercel will provide a URL for your deployed application

### Step 5: Configure Custom Domain (Optional)
1. From your project dashboard, go to "Settings" > "Domains"
2. Add your custom domain and follow the verification steps
3. Update your DNS settings as instructed by Vercel

## Option 2: Deploying to Netlify

### Prerequisites
- A GitHub, GitLab, or Bitbucket account with your project repository
- A Netlify account (you can sign up at [netlify.com](https://netlify.com))

### Step 1: Sign Up for Netlify
1. Go to [netlify.com](https://netlify.com)
2. Click "Sign Up" and choose to sign up with GitHub, GitLab, Bitbucket, or email
3. Follow the prompts to complete the sign-up process

### Step 2: Import Your Project
1. From the Netlify dashboard, click "Add new site" > "Import an existing project"
2. Connect to your Git provider if not already connected
3. Select the repository containing your frontend code

### Step 3: Configure Build Settings
1. Configure the build settings:
   - **Base directory**: `/financial_app_poc/frontend/financial-frontend` (adjust if your repository structure is different)
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`

2. Add the following environment variable:
   - **Key**: `VITE_API_URL`
   - **Value**: Your backend API URL (e.g., `https://financial-backend.onrender.com/api`)

3. Click "Deploy site"

### Step 4: Monitor Deployment
1. Netlify will build and deploy your application
2. You can monitor the build process in the "Deploys" tab
3. Once complete, Netlify will provide a URL for your deployed application

### Step 5: Configure Custom Domain (Optional)
1. From your site dashboard, go to "Site settings" > "Domain management"
2. Click "Add custom domain" and follow the verification steps
3. Update your DNS settings as instructed by Netlify

## Troubleshooting Common Issues

### Build Failures
- **Issue**: Build fails due to missing dependencies
  - **Solution**: Ensure all dependencies are listed in `package.json` and run `npm install` locally to verify

- **Issue**: Environment variables not accessible in the application
  - **Solution**: Ensure environment variables are prefixed with `VITE_` for Vite to expose them to the frontend

### CORS Issues
- **Issue**: API requests failing due to CORS errors
  - **Solution**: Ensure your backend has CORS configured to allow requests from your frontend domain

### Routing Issues
- **Issue**: 404 errors when refreshing pages with client-side routing
  - **Solution**: Add a `_redirects` file (Netlify) or `vercel.json` configuration (Vercel) to handle SPA routing

## Maintaining Your Deployment

### Continuous Deployment
Both Vercel and Netlify support continuous deployment. When you push changes to your repository, your site will automatically rebuild and deploy.

### Environment Variables
To update environment variables:
- **Vercel**: Go to your project settings > Environment Variables
- **Netlify**: Go to your site settings > Build & deploy > Environment

### Monitoring
Both platforms provide basic analytics and monitoring:
- **Vercel**: Check the "Analytics" tab in your project dashboard
- **Netlify**: Check the "Analytics" tab in your site dashboard

