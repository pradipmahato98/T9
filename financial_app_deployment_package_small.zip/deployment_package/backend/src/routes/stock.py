from flask import Blueprint, jsonify

stock_bp = Blueprint('stock', __name__, url_prefix='/api/stocks')

# Sample stock data
gainers = [
    {"symbol": "AAPL", "name": "Apple Inc.", "price": 189.45, "change": 5.67, "percentChange": 3.08},
    {"symbol": "MSFT", "name": "Microsoft Corp.", "price": 412.78, "change": 8.90, "percentChange": 2.20},
    {"symbol": "GOOGL", "name": "Alphabet Inc.", "price": 178.34, "change": 3.45, "percentChange": 1.97},
    {"symbol": "AMZN", "name": "Amazon.com Inc.", "price": 189.56, "change": 3.67, "percentChange": 1.97},
    {"symbol": "TSLA", "name": "Tesla Inc.", "price": 245.67, "change": 4.56, "percentChange": 1.89},
]

losers = [
    {"symbol": "NKE", "name": "Nike Inc.", "price": 98.45, "change": -3.56, "percentChange": -3.49},
    {"symbol": "DIS", "name": "Walt Disney Co.", "price": 112.34, "change": -3.45, "percentChange": -2.98},
    {"symbol": "KO", "name": "Coca-Cola Co.", "price": 65.78, "change": -1.89, "percentChange": -2.79},
    {"symbol": "PEP", "name": "PepsiCo Inc.", "price": 178.90, "change": -4.56, "percentChange": -2.48},
    {"symbol": "MCD", "name": "McDonald's Corp.", "price": 267.89, "change": -5.67, "percentChange": -2.07},
]

@stock_bp.route('/gainers', methods=['GET'])
def get_gainers():
    """Get top gaining stocks."""
    return jsonify({
        'status': 'success',
        'data': gainers
    })

@stock_bp.route('/losers', methods=['GET'])
def get_losers():
    """Get top losing stocks."""
    return jsonify({
        'status': 'success',
        'data': losers
    })

