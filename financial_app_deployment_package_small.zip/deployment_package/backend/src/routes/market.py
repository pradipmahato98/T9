from flask import Blueprint, jsonify

market_bp = Blueprint('market', __name__, url_prefix='/api/markets')

# Sample market data for different regions
market_data = {
    "nepal": [
        {"date": "2025-05-01", "value": 2145.67, "change": 12.45, "percentChange": 0.58},
        {"date": "2025-05-02", "value": 2156.89, "change": 11.22, "percentChange": 0.52},
        {"date": "2025-05-03", "value": 2178.34, "change": 21.45, "percentChange": 0.99},
        {"date": "2025-05-04", "value": 2165.78, "change": -12.56, "percentChange": -0.58},
        {"date": "2025-05-05", "value": 2189.45, "change": 23.67, "percentChange": 1.09},
        {"date": "2025-05-06", "value": 2201.23, "change": 11.78, "percentChange": 0.54},
        {"date": "2025-05-07", "value": 2215.67, "change": 14.44, "percentChange": 0.66},
    ],
    "india": [
        {"date": "2025-05-01", "value": 22456.78, "change": 145.67, "percentChange": 0.65},
        {"date": "2025-05-02", "value": 22567.89, "change": 111.11, "percentChange": 0.49},
        {"date": "2025-05-03", "value": 22789.45, "change": 221.56, "percentChange": 0.98},
        {"date": "2025-05-04", "value": 22678.34, "change": -111.11, "percentChange": -0.49},
        {"date": "2025-05-05", "value": 22890.12, "change": 211.78, "percentChange": 0.93},
        {"date": "2025-05-06", "value": 23012.45, "change": 122.33, "percentChange": 0.53},
        {"date": "2025-05-07", "value": 23145.67, "change": 133.22, "percentChange": 0.58},
    ],
    "china": [
        {"date": "2025-05-01", "value": 3456.78, "change": 23.45, "percentChange": 0.68},
        {"date": "2025-05-02", "value": 3478.90, "change": 22.12, "percentChange": 0.64},
        {"date": "2025-05-03", "value": 3512.34, "change": 33.44, "percentChange": 0.96},
        {"date": "2025-05-04", "value": 3489.56, "change": -22.78, "percentChange": -0.65},
        {"date": "2025-05-05", "value": 3523.78, "change": 34.22, "percentChange": 0.98},
        {"date": "2025-05-06", "value": 3545.67, "change": 21.89, "percentChange": 0.62},
        {"date": "2025-05-07", "value": 3578.90, "change": 33.23, "percentChange": 0.94},
    ],
    "australia": [
        {"date": "2025-05-01", "value": 7890.45, "change": 45.67, "percentChange": 0.58},
        {"date": "2025-05-02", "value": 7934.56, "change": 44.11, "percentChange": 0.56},
        {"date": "2025-05-03", "value": 7978.90, "change": 44.34, "percentChange": 0.56},
        {"date": "2025-05-04", "value": 7945.67, "change": -33.23, "percentChange": -0.42},
        {"date": "2025-05-05", "value": 7989.34, "change": 43.67, "percentChange": 0.55},
        {"date": "2025-05-06", "value": 8023.56, "change": 34.22, "percentChange": 0.43},
        {"date": "2025-05-07", "value": 8067.89, "change": 44.33, "percentChange": 0.55},
    ],
    "uk": [
        {"date": "2025-05-01", "value": 8234.56, "change": 56.78, "percentChange": 0.69},
        {"date": "2025-05-02", "value": 8289.67, "change": 55.11, "percentChange": 0.67},
        {"date": "2025-05-03", "value": 8345.78, "change": 56.11, "percentChange": 0.68},
        {"date": "2025-05-04", "value": 8312.45, "change": -33.33, "percentChange": -0.40},
        {"date": "2025-05-05", "value": 8378.90, "change": 66.45, "percentChange": 0.80},
        {"date": "2025-05-06", "value": 8423.56, "change": 44.66, "percentChange": 0.53},
        {"date": "2025-05-07", "value": 8478.90, "change": 55.34, "percentChange": 0.66},
    ],
    "usa": [
        {"date": "2025-05-01", "value": 4567.89, "change": 34.56, "percentChange": 0.76},
        {"date": "2025-05-02", "value": 4598.90, "change": 31.01, "percentChange": 0.68},
        {"date": "2025-05-03", "value": 4634.56, "change": 35.66, "percentChange": 0.78},
        {"date": "2025-05-04", "value": 4612.34, "change": -22.22, "percentChange": -0.48},
        {"date": "2025-05-05", "value": 4645.67, "change": 33.33, "percentChange": 0.72},
        {"date": "2025-05-06", "value": 4678.90, "change": 33.23, "percentChange": 0.71},
        {"date": "2025-05-07", "value": 4712.45, "change": 33.55, "percentChange": 0.72},
    ],
}

@market_bp.route('/<region>', methods=['GET'])
def get_market_data(region):
    """Get market data for a specific region."""
    if region not in market_data:
        return jsonify({
            'status': 'error',
            'message': f'Market data for region {region} not found'
        }), 404
    
    return jsonify({
        'status': 'success',
        'data': market_data[region]
    })

@market_bp.route('/', methods=['GET'])
def get_all_markets():
    """Get a list of all available markets."""
    markets = list(market_data.keys())
    
    return jsonify({
        'status': 'success',
        'data': markets
    })

