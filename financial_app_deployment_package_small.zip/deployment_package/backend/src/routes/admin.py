from flask import Blueprint, jsonify, request

admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')

# Sample admin dashboard data
dashboard_stats = {
    "users": {
        "total": 1250,
        "active": 876,
        "new": 45
    },
    "performance": {
        "responseTime": 120,  # ms
        "errorRate": 0.5,  # percentage
        "serverLoad": 35  # percentage
    },
    "api": {
        "requests": 45678,
        "errors": 234
    },
    "content": {
        "total": 156,
        "published": 142,
        "draft": 14
    }
}

system_metrics = [
    {"date": "2025-05-08", "users": 1150, "responseTime": 135, "errorRate": 0.7, "requests": 42000},
    {"date": "2025-05-09", "users": 1160, "responseTime": 130, "errorRate": 0.6, "requests": 42500},
    {"date": "2025-05-10", "users": 1165, "responseTime": 128, "errorRate": 0.6, "requests": 43000},
    {"date": "2025-05-11", "users": 1175, "responseTime": 125, "errorRate": 0.5, "requests": 43200},
    {"date": "2025-05-12", "users": 1185, "responseTime": 122, "errorRate": 0.5, "requests": 43500},
    {"date": "2025-05-13", "users": 1200, "responseTime": 120, "errorRate": 0.5, "requests": 44000},
    {"date": "2025-05-14", "users": 1210, "responseTime": 118, "errorRate": 0.4, "requests": 44200},
    {"date": "2025-05-15", "users": 1220, "responseTime": 122, "errorRate": 0.5, "requests": 44500},
    {"date": "2025-05-16", "users": 1225, "responseTime": 125, "errorRate": 0.6, "requests": 44800},
    {"date": "2025-05-17", "users": 1230, "responseTime": 123, "errorRate": 0.5, "requests": 45000},
    {"date": "2025-05-18", "users": 1235, "responseTime": 121, "errorRate": 0.5, "requests": 45200},
    {"date": "2025-05-19", "users": 1240, "responseTime": 120, "errorRate": 0.5, "requests": 45400},
    {"date": "2025-05-20", "users": 1245, "responseTime": 118, "errorRate": 0.4, "requests": 45600},
    {"date": "2025-05-21", "users": 1250, "responseTime": 120, "errorRate": 0.5, "requests": 45678},
]

users_list = [
    {"id": "12345", "username": "investor2025", "email": "investor@example.com", "fullName": "Alex Johnson", "accountType": "premium", "status": "active", "lastLogin": "2025-06-06T14:30:00Z"},
    {"id": "12346", "username": "trader123", "email": "trader@example.com", "fullName": "Sarah Williams", "accountType": "premium", "status": "active", "lastLogin": "2025-06-06T10:15:00Z"},
    {"id": "12347", "username": "finance_guru", "email": "guru@example.com", "fullName": "Michael Brown", "accountType": "basic", "status": "active", "lastLogin": "2025-06-05T16:45:00Z"},
    {"id": "12348", "username": "market_watcher", "email": "watcher@example.com", "fullName": "Emily Davis", "accountType": "basic", "status": "inactive", "lastLogin": "2025-05-28T09:20:00Z"},
    {"id": "12349", "username": "stock_master", "email": "master@example.com", "fullName": "David Wilson", "accountType": "premium", "status": "active", "lastLogin": "2025-06-06T08:10:00Z"},
]

system_logs = [
    {"id": 1, "level": "INFO", "service": "auth", "message": "User login successful", "timestamp": "2025-06-07T10:30:00Z", "details": {"userId": "12345"}},
    {"id": 2, "level": "WARNING", "service": "api", "message": "Rate limit approaching for API key", "timestamp": "2025-06-07T10:32:00Z", "details": {"apiKey": "abc123", "currentUsage": "95%"}},
    {"id": 3, "level": "ERROR", "service": "database", "message": "Database connection timeout", "timestamp": "2025-06-07T10:33:00Z", "details": {"retries": 3}},
    {"id": 4, "level": "INFO", "service": "market_data", "message": "Market data refresh completed", "timestamp": "2025-06-07T10:35:00Z", "details": {"regions": ["usa", "india", "china"]}},
    {"id": 5, "level": "ERROR", "service": "external_api", "message": "External API request failed", "timestamp": "2025-06-07T10:38:00Z", "details": {"provider": "StockData", "endpoint": "/quotes", "status": 503}},
]

content_items = [
    {"id": 1, "type": "article", "title": "Understanding Market Trends", "author": "Financial Expert", "status": "published", "publishDate": "2025-06-01T00:00:00Z", "views": 1250},
    {"id": 2, "type": "news", "title": "Central Bank Announces Interest Rate Decision", "author": "News Editor", "status": "published", "publishDate": "2025-06-07T10:30:00Z", "views": 876},
    {"id": 3, "type": "tutorial", "title": "How to Analyze Stock Charts", "author": "Trading Expert", "status": "published", "publishDate": "2025-05-15T00:00:00Z", "views": 2340},
    {"id": 4, "type": "article", "title": "Cryptocurrency Investment Strategies", "author": "Crypto Analyst", "status": "draft", "publishDate": None, "views": 0},
    {"id": 5, "type": "news", "title": "Tech Stocks Rally on Strong Earnings Reports", "author": "News Editor", "status": "published", "publishDate": "2025-06-07T09:15:00Z", "views": 543},
]

system_config = {
    "maintenance": {
        "enabled": False,
        "scheduledStart": "2025-06-15T02:00:00Z",
        "scheduledEnd": "2025-06-15T04:00:00Z",
        "message": "Scheduled maintenance for system upgrades"
    },
    "features": {
        "crypto": True,
        "forex": True,
        "commodities": True,
        "ai_predictions": False
    },
    "security": {
        "mfaRequired": True,
        "passwordPolicy": {
            "minLength": 10,
            "requireSpecialChars": True,
            "requireNumbers": True,
            "requireUppercase": True,
            "expiryDays": 90
        },
        "sessionTimeout": 30  # minutes
    }
}

version_history = [
    {
        "version": "1.5.0",
        "releaseDate": "2025-06-01T00:00:00Z",
        "changes": [
            "Added cryptocurrency market data",
            "Enhanced charting capabilities",
            "Improved mobile responsiveness",
            "Fixed bug in portfolio calculation"
        ],
        "deployedBy": "dev1"
    },
    {
        "version": "1.4.2",
        "releaseDate": "2025-05-15T00:00:00Z",
        "changes": [
            "Fixed security vulnerability in authentication",
            "Performance improvements for market data loading"
        ],
        "deployedBy": "dev1"
    },
    {
        "version": "1.4.1",
        "releaseDate": "2025-05-01T00:00:00Z",
        "changes": [
            "Bug fixes for user preferences",
            "Updated third-party libraries"
        ],
        "deployedBy": "dev1"
    }
]

ai_builder_status = {
    "status": "active",
    "models": [
        {
            "id": "market-predictor-v1",
            "type": "prediction",
            "status": "deployed",
            "accuracy": 0.87,
            "lastTrained": "2025-05-15T00:00:00Z"
        },
        {
            "id": "news-sentiment-v2",
            "type": "nlp",
            "status": "deployed",
            "accuracy": 0.92,
            "lastTrained": "2025-06-01T00:00:00Z"
        },
        {
            "id": "ui-optimizer-v1",
            "type": "optimization",
            "status": "training",
            "progress": 0.75,
            "startedAt": "2025-06-06T00:00:00Z"
        }
    ],
    "queue": [
        {
            "id": "code-generator-v1",
            "type": "code",
            "status": "queued",
            "estimatedStart": "2025-06-08T00:00:00Z"
        }
    ],
    "resources": {
        "cpuUsage": 65,
        "memoryUsage": 72,
        "gpuUsage": 88
    }
}

@admin_bp.route('/dashboard', methods=['GET'])
def get_dashboard():
    """Get admin dashboard statistics."""
    return jsonify({
        'status': 'success',
        'data': {
            'stats': dashboard_stats,
            'metrics': system_metrics
        }
    })

@admin_bp.route('/users', methods=['GET'])
def get_users():
    """Get list of users."""
    return jsonify({
        'status': 'success',
        'data': users_list
    })

@admin_bp.route('/logs', methods=['GET'])
def get_logs():
    """Get system logs."""
    level = request.args.get('level', 'all')
    
    if level != 'all':
        filtered_logs = [log for log in system_logs if log['level'].lower() == level.lower()]
    else:
        filtered_logs = system_logs
    
    return jsonify({
        'status': 'success',
        'data': filtered_logs
    })

@admin_bp.route('/content', methods=['GET'])
def get_content():
    """Get content items."""
    status = request.args.get('status', 'all')
    
    if status != 'all':
        filtered_content = [item for item in content_items if item['status'] == status]
    else:
        filtered_content = content_items
    
    return jsonify({
        'status': 'success',
        'data': filtered_content
    })

@admin_bp.route('/config', methods=['GET'])
def get_config():
    """Get system configuration."""
    return jsonify({
        'status': 'success',
        'data': system_config
    })

@admin_bp.route('/config', methods=['PUT'])
def update_config():
    """Update system configuration."""
    data = request.json
    
    # In a real application, this would update the actual configuration
    # For this demo, we'll just return the received data
    
    return jsonify({
        'status': 'success',
        'message': 'Configuration updated successfully',
        'data': data
    })

@admin_bp.route('/versions', methods=['GET'])
def get_versions():
    """Get version history."""
    return jsonify({
        'status': 'success',
        'data': version_history
    })

@admin_bp.route('/ai-builder', methods=['GET'])
def get_ai_builder():
    """Get AI builder status."""
    return jsonify({
        'status': 'success',
        'data': ai_builder_status
    })

