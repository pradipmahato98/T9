from flask import Blueprint, jsonify

news_bp = Blueprint('news', __name__, url_prefix='/api/news')

# Sample news data
news_items = [
    {
        "id": 1,
        "title": "Central Bank Announces Interest Rate Decision",
        "summary": "The central bank has decided to maintain current interest rates, citing stable inflation and economic growth.",
        "source": "Financial Times",
        "timestamp": "2025-06-07T10:30:00Z",
        "importance": "high",
    },
    {
        "id": 2,
        "title": "Tech Stocks Rally on Strong Earnings Reports",
        "summary": "Major technology companies reported better-than-expected earnings, driving a sector-wide rally.",
        "source": "Bloomberg",
        "timestamp": "2025-06-07T09:15:00Z",
        "importance": "medium",
    },
    {
        "id": 3,
        "title": "Oil Prices Stabilize After Recent Volatility",
        "summary": "Global oil prices have stabilized following a period of significant volatility due to geopolitical tensions.",
        "source": "Reuters",
        "timestamp": "2025-06-07T08:45:00Z",
        "importance": "medium",
    },
    {
        "id": 4,
        "title": "New Regulatory Framework for Cryptocurrency Announced",
        "summary": "Regulators have unveiled a comprehensive framework for cryptocurrency oversight, bringing clarity to the market.",
        "source": "CoinDesk",
        "timestamp": "2025-06-07T07:30:00Z",
        "importance": "high",
    },
    {
        "id": 5,
        "title": "Manufacturing Sector Shows Signs of Recovery",
        "summary": "Recent data indicates a recovery in the manufacturing sector, with increased production and new orders.",
        "source": "Economic Times",
        "timestamp": "2025-06-07T06:15:00Z",
        "importance": "medium",
    },
]

@news_bp.route('/', methods=['GET'])
def get_news():
    """Get latest market news."""
    return jsonify({
        'status': 'success',
        'data': news_items
    })

@news_bp.route('/<int:news_id>', methods=['GET'])
def get_news_item(news_id):
    """Get a specific news item by ID."""
    news_item = next((item for item in news_items if item["id"] == news_id), None)
    
    if not news_item:
        return jsonify({
            'status': 'error',
            'message': f'News item with ID {news_id} not found'
        }), 404
    
    return jsonify({
        'status': 'success',
        'data': news_item
    })

