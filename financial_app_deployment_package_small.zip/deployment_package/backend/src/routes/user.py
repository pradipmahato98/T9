from flask import Blueprint, jsonify, request

user_bp = Blueprint('user', __name__, url_prefix='/api/users')

# Sample user data
users = {
    "12345": {
        "id": "12345",
        "username": "investor2025",
        "email": "investor@example.com",
        "fullName": "Alex Johnson",
        "profileImage": "https://i.pravatar.cc/300",
        "accountType": "premium",
        "joinDate": "2024-01-15T00:00:00Z",
        "lastLogin": "2025-06-06T14:30:00Z",
        "preferences": {
            "defaultRegion": "usa",
            "theme": "system",
            "language": "en",
            "notifications": {
                "email": True,
                "push": True,
                "sms": False,
                "priceAlerts": True,
                "newsAlerts": True,
                "portfolioUpdates": True,
            },
            "defaultLandingPage": "dashboard",
            "dataRefreshRate": "30s",
        },
        "security": {
            "twoFactorEnabled": True,
            "lastPasswordChange": "2025-04-10T00:00:00Z",
            "loginHistory": [
                {"date": "2025-06-06T14:30:00Z", "device": "Chrome / Windows", "location": "New York, USA", "status": "success"},
                {"date": "2025-06-05T09:15:00Z", "device": "Safari / macOS", "location": "New York, USA", "status": "success"},
                {"date": "2025-06-03T18:45:00Z", "device": "Firefox / Linux", "location": "Boston, USA", "status": "success"},
                {"date": "2025-06-01T11:20:00Z", "device": "Chrome / Android", "location": "Chicago, USA", "status": "success"},
                {"date": "2025-05-28T16:05:00Z", "device": "Chrome / Windows", "location": "Seattle, USA", "status": "failed"},
            ],
        },
    }
}

@user_bp.route('/<user_id>', methods=['GET'])
def get_user(user_id):
    """Get user by ID."""
    if user_id not in users:
        return jsonify({
            'status': 'error',
            'message': f'User with ID {user_id} not found'
        }), 404
    
    return jsonify({
        'status': 'success',
        'data': users[user_id]
    })

@user_bp.route('/<user_id>', methods=['PUT'])
def update_user(user_id):
    """Update user information."""
    if user_id not in users:
        return jsonify({
            'status': 'error',
            'message': f'User with ID {user_id} not found'
        }), 404
    
    data = request.json
    
    # Update only allowed fields
    allowed_fields = ['fullName', 'email']
    for field in allowed_fields:
        if field in data:
            users[user_id][field] = data[field]
    
    return jsonify({
        'status': 'success',
        'message': 'User updated successfully',
        'data': users[user_id]
    })

@user_bp.route('/<user_id>/preferences', methods=['PUT'])
def update_preferences(user_id):
    """Update user preferences."""
    if user_id not in users:
        return jsonify({
            'status': 'error',
            'message': f'User with ID {user_id} not found'
        }), 404
    
    data = request.json
    
    # Update preferences
    for key, value in data.items():
        if key in users[user_id]['preferences']:
            users[user_id]['preferences'][key] = value
    
    return jsonify({
        'status': 'success',
        'message': 'Preferences updated successfully',
        'data': users[user_id]['preferences']
    })

