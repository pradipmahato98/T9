from flask import Flask, jsonify
from flask_cors import CORS
from routes.market import market_bp
from routes.stock import stock_bp
from routes.news import news_bp
from routes.user import user_bp
from routes.admin import admin_bp

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Register blueprints
app.register_blueprint(market_bp)
app.register_blueprint(stock_bp)
app.register_blueprint(news_bp)
app.register_blueprint(user_bp)
app.register_blueprint(admin_bp)

@app.route('/')
def index():
    return jsonify({
        'status': 'success',
        'message': 'Financial Markets API',
        'version': '1.0.0',
        'endpoints': [
            '/api/markets',
            '/api/stocks',
            '/api/news',
            '/api/users',
            '/api/admin'
        ]
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

